﻿namespace GraphSample.Models
{
    public class ConfidentialAppOption
    {
        public string ApplicationId { get; set; }
        public string TenentId { get; set; }
        public string ClientSecret { get; set; }
    }
}
