﻿namespace GraphSample.Models
{
    public class PublicClientOption
    {
        public string ApplicationId { get; set; }
        public string TenentId { get; set; }   
    }
}
